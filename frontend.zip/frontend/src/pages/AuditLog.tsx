const AuditLog = () => {
  return (
    <div>AuditLog</div>
  )
}

export default AuditLog